# CommanderHS
This is a modification of the Commander library for the Arbotix Commander that is available here:
https://github.com/Interbotix/arbotix/tree/master/libraries/Commander. I have modified it into two 
versions. This one for Hardware Serial and another for Software serial. This one allows you to pass in
any hardware serial connection for the communications. 

## Installation

You can install the libraries manually by copying the directories from the libraries folder into the libraries directory 
for Arduino on your computer. For windows this is in Documents/arduino/libraries. You can also follow the instructions
laid out on the arduino website for installing libraries: https://www.arduino.cc/en/guide/libraries. Use the install
from zip file option and load in the zip file for the library you are interested in that is located in the libraries
folder of this repo. 