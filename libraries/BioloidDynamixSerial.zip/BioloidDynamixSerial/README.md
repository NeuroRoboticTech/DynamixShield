# BioloidDynamixSerial
This is a modification of the BioloidController library for the Arbotix BioloidController that is available here:
https://github.com/Interbotix/arbotix/tree/master/libraries/Bioloid. I have modified it to work with the new DynamixSerial class for the DynamixShield. 

## Installation

You can install the library manually by copying this directory from the libraries folder into the libraries directory 
for Arduino on your computer. For windows this is in Documents/arduino/libraries. You can also follow the instructions
laid out on the arduino website for installing libraries: https://www.arduino.cc/en/guide/libraries. Use the install
from zip file option and load in the zip file for the library you are interested in that is located in the libraries
folder of this repo. 